const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');


registerLink.addEventListener(`click`, () => {
    wrapper.classList.add(`active`);
});

loginLink.addEventListener(`click`, () => {
    wrapper.classList.remove(`active`);
});

btnPopup.addEventListener(`click`, () => {
    wrapper.classList.add(`active-popup`);
});
iconClose.addEventListener(`click`, () => {
    wrapper.classList.remove(`active-popup`);
});




let sections = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');
window.onscroll = () => {
    sections.forEach(sec => {
        let top = window.scrollY;
        let offset = sec.offsetTop - 150;
        let height = sec.offsetHeight;
        let id = sec.getAttribute('id');
        if(top >= offset && top < offset + height) {
            navLinks.forEach(links => {
                links.classList.remove('active');
                document.querySelector('header nav a[href*=' + id + ']').classList.add('active');
            });
        };
    });
};
